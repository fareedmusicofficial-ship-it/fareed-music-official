MEWAT SUPER — PWA STARTER

Included:
- index.html: mobile-first Mewat Super music web app
- manifest.json: installable PWA metadata
- sw.js: basic offline app-shell cache
- icons/icon.svg: app icon

Publish on GitHub Pages:
1. Open your existing repository: fareed-music-official.
2. Upload/replace index.html and add manifest.json, sw.js, and the icons folder (with icon.svg).
3. Commit changes to main.
4. GitHub Pages is already enabled for the repository; wait for deployment.
5. Open https://fareedmusicofficial-ship-it.github.io/fareed-music-official/ in Chrome.
6. Chrome menu (⋮) > Add to Home screen / Install app.

IMPORTANT:
This is a frontend PWA prototype. Added audio is only available as a temporary local object URL and does not persist as a real hosted audio file after refresh. The song list metadata saves locally in the browser only. No multi-user account, cloud audio storage, public upload, royalty system, or music-store distribution is implemented. To make a public catalog for all listeners, add a backend/database and authorized storage/CDN. Use only audio and artwork you own or are licensed to distribute. App Store delivery is separate from streaming inside this app.
